const {test}=require('node:test');
const assert=require('node:assert/strict');
let C;try{C=require('../trips/core.js')}catch{C={}}
test('ordinary trip and route snapshot',()=>{const s=[{id:'a',name:'А',route:'База → А'}];const r=C.plan([],s,'2026-01-15',['a']);assert.equal(r.length,1);assert.equal(r[0].route,s[0].route)});
test('two shops, January boundary and December boundary',()=>{const s=[{id:'a',name:'А',route:'А'},{id:'b',name:'Б',route:'Б'}];assert.deepEqual(C.plan([],s,'2026-01-31',['a','b']).map(r=>r.date),['2026-01-31','2026-02-01']);assert.equal(C.nextDay('2026-12-31'),'2027-01-01');assert.equal(C.nextDay('2028-02-28'),'2028-02-29')});
test('duplicates are rejected atomically including second day',()=>{const s=[{id:'a',name:'А',route:'А'},{id:'b',name:'Б',route:'Б'}];const existing=[{id:'1',date:'2026-02-01',shopId:'b'}];assert.throws(()=>C.plan(existing,s,'2026-01-31',['a','b']),/уже/);assert.equal(existing.length,1)});
test('editing excludes self but rejects collision',()=>{const s=[{id:'a',name:'А',route:'А'}];const r=[{id:'1',date:'2026-01-01',shopId:'a'},{id:'2',date:'2026-01-02',shopId:'a'}];assert.equal(C.plan(r,s,'2026-01-01',['a'],'1')[0].id,'1');assert.throws(()=>C.plan(r,s,'2026-01-02',['a'],'1'),/уже/)});
test('CSV escapes delimiters, quotes, formulas and includes BOM',()=>{const csv=C.csv([{date:'2026-01-01',name:'=1+1',route:'А; "Б"\nВ'}]);assert.ok(csv.startsWith('\ufeff'));assert.ok(csv.includes('"\'=1+1"'));assert.ok(csv.includes('"А; ""Б""\nВ"'))});
test('invalid dates and unknown stores are rejected',()=>{assert.throws(()=>C.nextDay('2026-02-30'));assert.throws(()=>C.plan([],[],'2026-01-01',['x']))});
